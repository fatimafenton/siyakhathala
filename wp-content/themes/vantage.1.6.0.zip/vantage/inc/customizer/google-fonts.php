<?php

return array (
	'ABeeZee' =>
		array (
			0 => 'regular',
		),
	'Abel' =>
		array (
			0 => 'regular',
		),
	'Abril Fatface' =>
		array (
			0 => 'regular',
		),
	'Aclonica' =>
		array (
			0 => 'regular',
		),
	'Acme' =>
		array (
			0 => 'regular',
		),
	'Actor' =>
		array (
			0 => 'regular',
		),
	'Adamina' =>
		array (
			0 => 'regular',
		),
	'Advent Pro' =>
		array (
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
		),
	'Aguafina Script' =>
		array (
			0 => 'regular',
		),
	'Akronim' =>
		array (
			0 => 'regular',
		),
	'Aladin' =>
		array (
			0 => 'regular',
		),
	'Aldrich' =>
		array (
			0 => 'regular',
		),
	'Alef' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Alegreya' =>
		array (
			0 => 'regular',
			1 => '700',
			2 => '900',
		),
	'Alegreya SC' =>
		array (
			0 => 'regular',
			1 => '700',
			2 => '900',
		),
	'Alegreya Sans' =>
		array (
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '700',
			5 => '800',
			6 => '900',
		),
	'Alegreya Sans SC' =>
		array (
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '700',
			5 => '800',
			6 => '900',
		),
	'Alex Brush' =>
		array (
			0 => 'regular',
		),
	'Alfa Slab One' =>
		array (
			0 => 'regular',
		),
	'Alice' =>
		array (
			0 => 'regular',
		),
	'Alike' =>
		array (
			0 => 'regular',
		),
	'Alike Angular' =>
		array (
			0 => 'regular',
		),
	'Allan' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Allerta' =>
		array (
			0 => 'regular',
		),
	'Allerta Stencil' =>
		array (
			0 => 'regular',
		),
	'Allura' =>
		array (
			0 => 'regular',
		),
	'Almendra' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Almendra Display' =>
		array (
			0 => 'regular',
		),
	'Almendra SC' =>
		array (
			0 => 'regular',
		),
	'Amarante' =>
		array (
			0 => 'regular',
		),
	'Amaranth' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Amatic SC' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Amethysta' =>
		array (
			0 => 'regular',
		),
	'Anaheim' =>
		array (
			0 => 'regular',
		),
	'Andada' =>
		array (
			0 => 'regular',
		),
	'Andika' =>
		array (
			0 => 'regular',
		),
	'Angkor' =>
		array (
			0 => 'regular',
		),
	'Annie Use Your Telescope' =>
		array (
			0 => 'regular',
		),
	'Anonymous Pro' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Antic' =>
		array (
			0 => 'regular',
		),
	'Antic Didone' =>
		array (
			0 => 'regular',
		),
	'Antic Slab' =>
		array (
			0 => 'regular',
		),
	'Anton' =>
		array (
			0 => 'regular',
		),
	'Arapey' =>
		array (
			0 => 'regular',
		),
	'Arbutus' =>
		array (
			0 => 'regular',
		),
	'Arbutus Slab' =>
		array (
			0 => 'regular',
		),
	'Architects Daughter' =>
		array (
			0 => 'regular',
		),
	'Archivo Black' =>
		array (
			0 => 'regular',
		),
	'Archivo Narrow' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Arimo' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Arizonia' =>
		array (
			0 => 'regular',
		),
	'Armata' =>
		array (
			0 => 'regular',
		),
	'Artifika' =>
		array (
			0 => 'regular',
		),
	'Arvo' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Asap' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Asset' =>
		array (
			0 => 'regular',
		),
	'Astloch' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Asul' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Atomic Age' =>
		array (
			0 => 'regular',
		),
	'Aubrey' =>
		array (
			0 => 'regular',
		),
	'Audiowide' =>
		array (
			0 => 'regular',
		),
	'Autour One' =>
		array (
			0 => 'regular',
		),
	'Average' =>
		array (
			0 => 'regular',
		),
	'Average Sans' =>
		array (
			0 => 'regular',
		),
	'Averia Gruesa Libre' =>
		array (
			0 => 'regular',
		),
	'Averia Libre' =>
		array (
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
	'Averia Sans Libre' =>
		array (
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
	'Averia Serif Libre' =>
		array (
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
	'Bad Script' =>
		array (
			0 => 'regular',
		),
	'Balthazar' =>
		array (
			0 => 'regular',
		),
	'Bangers' =>
		array (
			0 => 'regular',
		),
	'Basic' =>
		array (
			0 => 'regular',
		),
	'Battambang' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Baumans' =>
		array (
			0 => 'regular',
		),
	'Bayon' =>
		array (
			0 => 'regular',
		),
	'Belgrano' =>
		array (
			0 => 'regular',
		),
	'Belleza' =>
		array (
			0 => 'regular',
		),
	'BenchNine' =>
		array (
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
	'Bentham' =>
		array (
			0 => 'regular',
		),
	'Berkshire Swash' =>
		array (
			0 => 'regular',
		),
	'Bevan' =>
		array (
			0 => 'regular',
		),
	'Bigelow Rules' =>
		array (
			0 => 'regular',
		),
	'Bigshot One' =>
		array (
			0 => 'regular',
		),
	'Bilbo' =>
		array (
			0 => 'regular',
		),
	'Bilbo Swash Caps' =>
		array (
			0 => 'regular',
		),
	'Bitter' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Black Ops One' =>
		array (
			0 => 'regular',
		),
	'Bokor' =>
		array (
			0 => 'regular',
		),
	'Bonbon' =>
		array (
			0 => 'regular',
		),
	'Boogaloo' =>
		array (
			0 => 'regular',
		),
	'Bowlby One' =>
		array (
			0 => 'regular',
		),
	'Bowlby One SC' =>
		array (
			0 => 'regular',
		),
	'Brawler' =>
		array (
			0 => 'regular',
		),
	'Bree Serif' =>
		array (
			0 => 'regular',
		),
	'Bubblegum Sans' =>
		array (
			0 => 'regular',
		),
	'Bubbler One' =>
		array (
			0 => 'regular',
		),
	'Buda' =>
		array (
			0 => '300',
		),
	'Buenard' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Butcherman' =>
		array (
			0 => 'regular',
		),
	'Butterfly Kids' =>
		array (
			0 => 'regular',
		),
	'Cabin' =>
		array (
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Cabin Condensed' =>
		array (
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Cabin Sketch' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Caesar Dressing' =>
		array (
			0 => 'regular',
		),
	'Cagliostro' =>
		array (
			0 => 'regular',
		),
	'Calligraffitti' =>
		array (
			0 => 'regular',
		),
	'Cambo' =>
		array (
			0 => 'regular',
		),
	'Candal' =>
		array (
			0 => 'regular',
		),
	'Cantarell' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Cantata One' =>
		array (
			0 => 'regular',
		),
	'Cantora One' =>
		array (
			0 => 'regular',
		),
	'Capriola' =>
		array (
			0 => 'regular',
		),
	'Cardo' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Carme' =>
		array (
			0 => 'regular',
		),
	'Carrois Gothic' =>
		array (
			0 => 'regular',
		),
	'Carrois Gothic SC' =>
		array (
			0 => 'regular',
		),
	'Carter One' =>
		array (
			0 => 'regular',
		),
	'Caudex' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Cedarville Cursive' =>
		array (
			0 => 'regular',
		),
	'Ceviche One' =>
		array (
			0 => 'regular',
		),
	'Changa One' =>
		array (
			0 => 'regular',
		),
	'Chango' =>
		array (
			0 => 'regular',
		),
	'Chau Philomene One' =>
		array (
			0 => 'regular',
		),
	'Chela One' =>
		array (
			0 => 'regular',
		),
	'Chelsea Market' =>
		array (
			0 => 'regular',
		),
	'Chenla' =>
		array (
			0 => 'regular',
		),
	'Cherry Cream Soda' =>
		array (
			0 => 'regular',
		),
	'Cherry Swash' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Chewy' =>
		array (
			0 => 'regular',
		),
	'Chicle' =>
		array (
			0 => 'regular',
		),
	'Chivo' =>
		array (
			0 => 'regular',
			1 => '900',
		),
	'Cinzel' =>
		array (
			0 => 'regular',
			1 => '700',
			2 => '900',
		),
	'Cinzel Decorative' =>
		array (
			0 => 'regular',
			1 => '700',
			2 => '900',
		),
	'Clicker Script' =>
		array (
			0 => 'regular',
		),
	'Coda' =>
		array (
			0 => 'regular',
			1 => '800',
		),
	'Coda Caption' =>
		array (
			0 => '800',
		),
	'Codystar' =>
		array (
			0 => '300',
			1 => 'regular',
		),
	'Combo' =>
		array (
			0 => 'regular',
		),
	'Comfortaa' =>
		array (
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
	'Coming Soon' =>
		array (
			0 => 'regular',
		),
	'Concert One' =>
		array (
			0 => 'regular',
		),
	'Condiment' =>
		array (
			0 => 'regular',
		),
	'Content' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Contrail One' =>
		array (
			0 => 'regular',
		),
	'Convergence' =>
		array (
			0 => 'regular',
		),
	'Cookie' =>
		array (
			0 => 'regular',
		),
	'Copse' =>
		array (
			0 => 'regular',
		),
	'Corben' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Courgette' =>
		array (
			0 => 'regular',
		),
	'Cousine' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Coustard' =>
		array (
			0 => 'regular',
			1 => '900',
		),
	'Covered By Your Grace' =>
		array (
			0 => 'regular',
		),
	'Crafty Girls' =>
		array (
			0 => 'regular',
		),
	'Creepster' =>
		array (
			0 => 'regular',
		),
	'Crete Round' =>
		array (
			0 => 'regular',
		),
	'Crimson Text' =>
		array (
			0 => 'regular',
			1 => '600',
			2 => '700',
		),
	'Croissant One' =>
		array (
			0 => 'regular',
		),
	'Crushed' =>
		array (
			0 => 'regular',
		),
	'Cuprum' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Cutive' =>
		array (
			0 => 'regular',
		),
	'Cutive Mono' =>
		array (
			0 => 'regular',
		),
	'Damion' =>
		array (
			0 => 'regular',
		),
	'Dancing Script' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Dangrek' =>
		array (
			0 => 'regular',
		),
	'Dawning of a New Day' =>
		array (
			0 => 'regular',
		),
	'Days One' =>
		array (
			0 => 'regular',
		),
	'Delius' =>
		array (
			0 => 'regular',
		),
	'Delius Swash Caps' =>
		array (
			0 => 'regular',
		),
	'Delius Unicase' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Della Respira' =>
		array (
			0 => 'regular',
		),
	'Denk One' =>
		array (
			0 => 'regular',
		),
	'Devonshire' =>
		array (
			0 => 'regular',
		),
	'Didact Gothic' =>
		array (
			0 => 'regular',
		),
	'Diplomata' =>
		array (
			0 => 'regular',
		),
	'Diplomata SC' =>
		array (
			0 => 'regular',
		),
	'Domine' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Donegal One' =>
		array (
			0 => 'regular',
		),
	'Doppio One' =>
		array (
			0 => 'regular',
		),
	'Dorsa' =>
		array (
			0 => 'regular',
		),
	'Dosis' =>
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
		),
	'Dr Sugiyama' =>
		array (
			0 => 'regular',
		),
	'Droid Sans' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Droid Sans Mono' =>
		array (
			0 => 'regular',
		),
	'Droid Serif' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Duru Sans' =>
		array (
			0 => 'regular',
		),
	'Dynalight' =>
		array (
			0 => 'regular',
		),
	'EB Garamond' =>
		array (
			0 => 'regular',
		),
	'Eagle Lake' =>
		array (
			0 => 'regular',
		),
	'Eater' =>
		array (
			0 => 'regular',
		),
	'Economica' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Electrolize' =>
		array (
			0 => 'regular',
		),
	'Elsie' =>
		array (
			0 => 'regular',
			1 => '900',
		),
	'Elsie Swash Caps' =>
		array (
			0 => 'regular',
			1 => '900',
		),
	'Emblema One' =>
		array (
			0 => 'regular',
		),
	'Emilys Candy' =>
		array (
			0 => 'regular',
		),
	'Engagement' =>
		array (
			0 => 'regular',
		),
	'Englebert' =>
		array (
			0 => 'regular',
		),
	'Enriqueta' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Erica One' =>
		array (
			0 => 'regular',
		),
	'Esteban' =>
		array (
			0 => 'regular',
		),
	'Euphoria Script' =>
		array (
			0 => 'regular',
		),
	'Ewert' =>
		array (
			0 => 'regular',
		),
	'Exo' =>
		array (
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Exo 2' =>
		array (
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Expletus Sans' =>
		array (
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
	'Fanwood Text' =>
		array (
			0 => 'regular',
		),
	'Fascinate' =>
		array (
			0 => 'regular',
		),
	'Fascinate Inline' =>
		array (
			0 => 'regular',
		),
	'Faster One' =>
		array (
			0 => 'regular',
		),
	'Fasthand' =>
		array (
			0 => 'regular',
		),
	'Fauna One' =>
		array (
			0 => 'regular',
		),
	'Federant' =>
		array (
			0 => 'regular',
		),
	'Federo' =>
		array (
			0 => 'regular',
		),
	'Felipa' =>
		array (
			0 => 'regular',
		),
	'Fenix' =>
		array (
			0 => 'regular',
		),
	'Finger Paint' =>
		array (
			0 => 'regular',
		),
	'Fjalla One' =>
		array (
			0 => 'regular',
		),
	'Fjord One' =>
		array (
			0 => 'regular',
		),
	'Flamenco' =>
		array (
			0 => '300',
			1 => 'regular',
		),
	'Flavors' =>
		array (
			0 => 'regular',
		),
	'Fondamento' =>
		array (
			0 => 'regular',
		),
	'Fontdiner Swanky' =>
		array (
			0 => 'regular',
		),
	'Forum' =>
		array (
			0 => 'regular',
		),
	'Francois One' =>
		array (
			0 => 'regular',
		),
	'Freckle Face' =>
		array (
			0 => 'regular',
		),
	'Fredericka the Great' =>
		array (
			0 => 'regular',
		),
	'Fredoka One' =>
		array (
			0 => 'regular',
		),
	'Freehand' =>
		array (
			0 => 'regular',
		),
	'Fresca' =>
		array (
			0 => 'regular',
		),
	'Frijole' =>
		array (
			0 => 'regular',
		),
	'Fruktur' =>
		array (
			0 => 'regular',
		),
	'Fugaz One' =>
		array (
			0 => 'regular',
		),
	'GFS Didot' =>
		array (
			0 => 'regular',
		),
	'GFS Neohellenic' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Gabriela' =>
		array (
			0 => 'regular',
		),
	'Gafata' =>
		array (
			0 => 'regular',
		),
	'Galdeano' =>
		array (
			0 => 'regular',
		),
	'Galindo' =>
		array (
			0 => 'regular',
		),
	'Gentium Basic' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Gentium Book Basic' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Geo' =>
		array (
			0 => 'regular',
		),
	'Geostar' =>
		array (
			0 => 'regular',
		),
	'Geostar Fill' =>
		array (
			0 => 'regular',
		),
	'Germania One' =>
		array (
			0 => 'regular',
		),
	'Gilda Display' =>
		array (
			0 => 'regular',
		),
	'Give You Glory' =>
		array (
			0 => 'regular',
		),
	'Glass Antiqua' =>
		array (
			0 => 'regular',
		),
	'Glegoo' =>
		array (
			0 => 'regular',
		),
	'Gloria Hallelujah' =>
		array (
			0 => 'regular',
		),
	'Goblin One' =>
		array (
			0 => 'regular',
		),
	'Gochi Hand' =>
		array (
			0 => 'regular',
		),
	'Gorditas' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Goudy Bookletter 1911' =>
		array (
			0 => 'regular',
		),
	'Graduate' =>
		array (
			0 => 'regular',
		),
	'Grand Hotel' =>
		array (
			0 => 'regular',
		),
	'Gravitas One' =>
		array (
			0 => 'regular',
		),
	'Great Vibes' =>
		array (
			0 => 'regular',
		),
	'Griffy' =>
		array (
			0 => 'regular',
		),
	'Gruppo' =>
		array (
			0 => 'regular',
		),
	'Gudea' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Habibi' =>
		array (
			0 => 'regular',
		),
	'Hammersmith One' =>
		array (
			0 => 'regular',
		),
	'Hanalei' =>
		array (
			0 => 'regular',
		),
	'Hanalei Fill' =>
		array (
			0 => 'regular',
		),
	'Handlee' =>
		array (
			0 => 'regular',
		),
	'Hanuman' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Happy Monkey' =>
		array (
			0 => 'regular',
		),
	'Headland One' =>
		array (
			0 => 'regular',
		),
	'Henny Penny' =>
		array (
			0 => 'regular',
		),
	'Herr Von Muellerhoff' =>
		array (
			0 => 'regular',
		),
	'Holtwood One SC' =>
		array (
			0 => 'regular',
		),
	'Homemade Apple' =>
		array (
			0 => 'regular',
		),
	'Homenaje' =>
		array (
			0 => 'regular',
		),
	'IM Fell DW Pica' =>
		array (
			0 => 'regular',
		),
	'IM Fell DW Pica SC' =>
		array (
			0 => 'regular',
		),
	'IM Fell Double Pica' =>
		array (
			0 => 'regular',
		),
	'IM Fell Double Pica SC' =>
		array (
			0 => 'regular',
		),
	'IM Fell English' =>
		array (
			0 => 'regular',
		),
	'IM Fell English SC' =>
		array (
			0 => 'regular',
		),
	'IM Fell French Canon' =>
		array (
			0 => 'regular',
		),
	'IM Fell French Canon SC' =>
		array (
			0 => 'regular',
		),
	'IM Fell Great Primer' =>
		array (
			0 => 'regular',
		),
	'IM Fell Great Primer SC' =>
		array (
			0 => 'regular',
		),
	'Iceberg' =>
		array (
			0 => 'regular',
		),
	'Iceland' =>
		array (
			0 => 'regular',
		),
	'Imprima' =>
		array (
			0 => 'regular',
		),
	'Inconsolata' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Inder' =>
		array (
			0 => 'regular',
		),
	'Indie Flower' =>
		array (
			0 => 'regular',
		),
	'Inika' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Irish Grover' =>
		array (
			0 => 'regular',
		),
	'Istok Web' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Italiana' =>
		array (
			0 => 'regular',
		),
	'Italianno' =>
		array (
			0 => 'regular',
		),
	'Jacques Francois' =>
		array (
			0 => 'regular',
		),
	'Jacques Francois Shadow' =>
		array (
			0 => 'regular',
		),
	'Jim Nightshade' =>
		array (
			0 => 'regular',
		),
	'Jockey One' =>
		array (
			0 => 'regular',
		),
	'Jolly Lodger' =>
		array (
			0 => 'regular',
		),
	'Josefin Sans' =>
		array (
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '600',
			4 => '700',
		),
	'Josefin Slab' =>
		array (
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '600',
			4 => '700',
		),
	'Joti One' =>
		array (
			0 => 'regular',
		),
	'Judson' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Julee' =>
		array (
			0 => 'regular',
		),
	'Julius Sans One' =>
		array (
			0 => 'regular',
		),
	'Junge' =>
		array (
			0 => 'regular',
		),
	'Jura' =>
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
		),
	'Just Another Hand' =>
		array (
			0 => 'regular',
		),
	'Just Me Again Down Here' =>
		array (
			0 => 'regular',
		),
	'Kameron' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Kantumruy' =>
		array (
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
	'Karla' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Kaushan Script' =>
		array (
			0 => 'regular',
		),
	'Kavoon' =>
		array (
			0 => 'regular',
		),
	'Kdam Thmor' =>
		array (
			0 => 'regular',
		),
	'Keania One' =>
		array (
			0 => 'regular',
		),
	'Kelly Slab' =>
		array (
			0 => 'regular',
		),
	'Kenia' =>
		array (
			0 => 'regular',
		),
	'Khmer' =>
		array (
			0 => 'regular',
		),
	'Kite One' =>
		array (
			0 => 'regular',
		),
	'Knewave' =>
		array (
			0 => 'regular',
		),
	'Kotta One' =>
		array (
			0 => 'regular',
		),
	'Koulen' =>
		array (
			0 => 'regular',
		),
	'Kranky' =>
		array (
			0 => 'regular',
		),
	'Kreon' =>
		array (
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
	'Kristi' =>
		array (
			0 => 'regular',
		),
	'Krona One' =>
		array (
			0 => 'regular',
		),
	'La Belle Aurore' =>
		array (
			0 => 'regular',
		),
	'Lancelot' =>
		array (
			0 => 'regular',
		),
	'Lato' =>
		array (
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '700',
			4 => '900',
		),
	'League Script' =>
		array (
			0 => 'regular',
		),
	'Leckerli One' =>
		array (
			0 => 'regular',
		),
	'Ledger' =>
		array (
			0 => 'regular',
		),
	'Lekton' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Lemon' =>
		array (
			0 => 'regular',
		),
	'Libre Baskerville' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Life Savers' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Lilita One' =>
		array (
			0 => 'regular',
		),
	'Lily Script One' =>
		array (
			0 => 'regular',
		),
	'Limelight' =>
		array (
			0 => 'regular',
		),
	'Linden Hill' =>
		array (
			0 => 'regular',
		),
	'Lobster' =>
		array (
			0 => 'regular',
		),
	'Lobster Two' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Londrina Outline' =>
		array (
			0 => 'regular',
		),
	'Londrina Shadow' =>
		array (
			0 => 'regular',
		),
	'Londrina Sketch' =>
		array (
			0 => 'regular',
		),
	'Londrina Solid' =>
		array (
			0 => 'regular',
		),
	'Lora' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Love Ya Like A Sister' =>
		array (
			0 => 'regular',
		),
	'Loved by the King' =>
		array (
			0 => 'regular',
		),
	'Lovers Quarrel' =>
		array (
			0 => 'regular',
		),
	'Luckiest Guy' =>
		array (
			0 => 'regular',
		),
	'Lusitana' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Lustria' =>
		array (
			0 => 'regular',
		),
	'Macondo' =>
		array (
			0 => 'regular',
		),
	'Macondo Swash Caps' =>
		array (
			0 => 'regular',
		),
	'Magra' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Maiden Orange' =>
		array (
			0 => 'regular',
		),
	'Mako' =>
		array (
			0 => 'regular',
		),
	'Marcellus' =>
		array (
			0 => 'regular',
		),
	'Marcellus SC' =>
		array (
			0 => 'regular',
		),
	'Marck Script' =>
		array (
			0 => 'regular',
		),
	'Margarine' =>
		array (
			0 => 'regular',
		),
	'Marko One' =>
		array (
			0 => 'regular',
		),
	'Marmelad' =>
		array (
			0 => 'regular',
		),
	'Marvel' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Mate' =>
		array (
			0 => 'regular',
		),
	'Mate SC' =>
		array (
			0 => 'regular',
		),
	'Maven Pro' =>
		array (
			0 => 'regular',
			1 => '500',
			2 => '700',
			3 => '900',
		),
	'McLaren' =>
		array (
			0 => 'regular',
		),
	'Meddon' =>
		array (
			0 => 'regular',
		),
	'MedievalSharp' =>
		array (
			0 => 'regular',
		),
	'Medula One' =>
		array (
			0 => 'regular',
		),
	'Megrim' =>
		array (
			0 => 'regular',
		),
	'Meie Script' =>
		array (
			0 => 'regular',
		),
	'Merienda' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Merienda One' =>
		array (
			0 => 'regular',
		),
	'Merriweather' =>
		array (
			0 => '300',
			1 => 'regular',
			2 => '700',
			3 => '900',
		),
	'Merriweather Sans' =>
		array (
			0 => '300',
			1 => 'regular',
			2 => '700',
			3 => '800',
		),
	'Metal' =>
		array (
			0 => 'regular',
		),
	'Metal Mania' =>
		array (
			0 => 'regular',
		),
	'Metamorphous' =>
		array (
			0 => 'regular',
		),
	'Metrophobic' =>
		array (
			0 => 'regular',
		),
	'Michroma' =>
		array (
			0 => 'regular',
		),
	'Milonga' =>
		array (
			0 => 'regular',
		),
	'Miltonian' =>
		array (
			0 => 'regular',
		),
	'Miltonian Tattoo' =>
		array (
			0 => 'regular',
		),
	'Miniver' =>
		array (
			0 => 'regular',
		),
	'Miss Fajardose' =>
		array (
			0 => 'regular',
		),
	'Modern Antiqua' =>
		array (
			0 => 'regular',
		),
	'Molengo' =>
		array (
			0 => 'regular',
		),
	'Molle' =>
		array (
		),
	'Monda' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Monofett' =>
		array (
			0 => 'regular',
		),
	'Monoton' =>
		array (
			0 => 'regular',
		),
	'Monsieur La Doulaise' =>
		array (
			0 => 'regular',
		),
	'Montaga' =>
		array (
			0 => 'regular',
		),
	'Montez' =>
		array (
			0 => 'regular',
		),
	'Montserrat' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Montserrat Alternates' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Montserrat Subrayada' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Moul' =>
		array (
			0 => 'regular',
		),
	'Moulpali' =>
		array (
			0 => 'regular',
		),
	'Mountains of Christmas' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Mouse Memoirs' =>
		array (
			0 => 'regular',
		),
	'Mr Bedfort' =>
		array (
			0 => 'regular',
		),
	'Mr Dafoe' =>
		array (
			0 => 'regular',
		),
	'Mr De Haviland' =>
		array (
			0 => 'regular',
		),
	'Mrs Saint Delafield' =>
		array (
			0 => 'regular',
		),
	'Mrs Sheppards' =>
		array (
			0 => 'regular',
		),
	'Muli' =>
		array (
			0 => '300',
			1 => 'regular',
		),
	'Mystery Quest' =>
		array (
			0 => 'regular',
		),
	'Neucha' =>
		array (
			0 => 'regular',
		),
	'Neuton' =>
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '700',
			4 => '800',
		),
	'New Rocker' =>
		array (
			0 => 'regular',
		),
	'News Cycle' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Niconne' =>
		array (
			0 => 'regular',
		),
	'Nixie One' =>
		array (
			0 => 'regular',
		),
	'Nobile' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Nokora' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Norican' =>
		array (
			0 => 'regular',
		),
	'Nosifer' =>
		array (
			0 => 'regular',
		),
	'Nothing You Could Do' =>
		array (
			0 => 'regular',
		),
	'Noticia Text' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Noto Sans' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Noto Serif' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Nova Cut' =>
		array (
			0 => 'regular',
		),
	'Nova Flat' =>
		array (
			0 => 'regular',
		),
	'Nova Mono' =>
		array (
			0 => 'regular',
		),
	'Nova Oval' =>
		array (
			0 => 'regular',
		),
	'Nova Round' =>
		array (
			0 => 'regular',
		),
	'Nova Script' =>
		array (
			0 => 'regular',
		),
	'Nova Slim' =>
		array (
			0 => 'regular',
		),
	'Nova Square' =>
		array (
			0 => 'regular',
		),
	'Numans' =>
		array (
			0 => 'regular',
		),
	'Nunito' =>
		array (
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
	'Odor Mean Chey' =>
		array (
			0 => 'regular',
		),
	'Offside' =>
		array (
			0 => 'regular',
		),
	'Old Standard TT' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Oldenburg' =>
		array (
			0 => 'regular',
		),
	'Oleo Script' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Oleo Script Swash Caps' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Open Sans' =>
		array (
			0 => '300',
			1 => 'regular',
			2 => '600',
			3 => '700',
			4 => '800',
		),
	'Open Sans Condensed' =>
		array (
			0 => '300',
			1 => '700',
		),
	'Oranienbaum' =>
		array (
			0 => 'regular',
		),
	'Orbitron' =>
		array (
			0 => 'regular',
			1 => '500',
			2 => '700',
			3 => '900',
		),
	'Oregano' =>
		array (
			0 => 'regular',
		),
	'Orienta' =>
		array (
			0 => 'regular',
		),
	'Original Surfer' =>
		array (
			0 => 'regular',
		),
	'Oswald' =>
		array (
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
	'Over the Rainbow' =>
		array (
			0 => 'regular',
		),
	'Overlock' =>
		array (
			0 => 'regular',
			1 => '700',
			2 => '900',
		),
	'Overlock SC' =>
		array (
			0 => 'regular',
		),
	'Ovo' =>
		array (
			0 => 'regular',
		),
	'Oxygen' =>
		array (
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
	'Oxygen Mono' =>
		array (
			0 => 'regular',
		),
	'PT Mono' =>
		array (
			0 => 'regular',
		),
	'PT Sans' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'PT Sans Caption' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'PT Sans Narrow' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'PT Serif' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'PT Serif Caption' =>
		array (
			0 => 'regular',
		),
	'Pacifico' =>
		array (
			0 => 'regular',
		),
	'Paprika' =>
		array (
			0 => 'regular',
		),
	'Parisienne' =>
		array (
			0 => 'regular',
		),
	'Passero One' =>
		array (
			0 => 'regular',
		),
	'Passion One' =>
		array (
			0 => 'regular',
			1 => '700',
			2 => '900',
		),
	'Pathway Gothic One' =>
		array (
			0 => 'regular',
		),
	'Patrick Hand' =>
		array (
			0 => 'regular',
		),
	'Patrick Hand SC' =>
		array (
			0 => 'regular',
		),
	'Patua One' =>
		array (
			0 => 'regular',
		),
	'Paytone One' =>
		array (
			0 => 'regular',
		),
	'Peralta' =>
		array (
			0 => 'regular',
		),
	'Permanent Marker' =>
		array (
			0 => 'regular',
		),
	'Petit Formal Script' =>
		array (
			0 => 'regular',
		),
	'Petrona' =>
		array (
			0 => 'regular',
		),
	'Philosopher' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Piedra' =>
		array (
			0 => 'regular',
		),
	'Pinyon Script' =>
		array (
			0 => 'regular',
		),
	'Pirata One' =>
		array (
			0 => 'regular',
		),
	'Plaster' =>
		array (
			0 => 'regular',
		),
	'Play' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Playball' =>
		array (
			0 => 'regular',
		),
	'Playfair Display' =>
		array (
			0 => 'regular',
			1 => '700',
			2 => '900',
		),
	'Playfair Display SC' =>
		array (
			0 => 'regular',
			1 => '700',
			2 => '900',
		),
	'Podkova' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Poiret One' =>
		array (
			0 => 'regular',
		),
	'Poller One' =>
		array (
			0 => 'regular',
		),
	'Poly' =>
		array (
			0 => 'regular',
		),
	'Pompiere' =>
		array (
			0 => 'regular',
		),
	'Pontano Sans' =>
		array (
			0 => 'regular',
		),
	'Port Lligat Sans' =>
		array (
			0 => 'regular',
		),
	'Port Lligat Slab' =>
		array (
			0 => 'regular',
		),
	'Prata' =>
		array (
			0 => 'regular',
		),
	'Preahvihear' =>
		array (
			0 => 'regular',
		),
	'Press Start 2P' =>
		array (
			0 => 'regular',
		),
	'Princess Sofia' =>
		array (
			0 => 'regular',
		),
	'Prociono' =>
		array (
			0 => 'regular',
		),
	'Prosto One' =>
		array (
			0 => 'regular',
		),
	'Puritan' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Purple Purse' =>
		array (
			0 => 'regular',
		),
	'Quando' =>
		array (
			0 => 'regular',
		),
	'Quantico' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Quattrocento' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Quattrocento Sans' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Questrial' =>
		array (
			0 => 'regular',
		),
	'Quicksand' =>
		array (
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
	'Quintessential' =>
		array (
			0 => 'regular',
		),
	'Qwigley' =>
		array (
			0 => 'regular',
		),
	'Racing Sans One' =>
		array (
			0 => 'regular',
		),
	'Radley' =>
		array (
			0 => 'regular',
		),
	'Raleway' =>
		array (
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
	'Raleway Dots' =>
		array (
			0 => 'regular',
		),
	'Rambla' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Rammetto One' =>
		array (
			0 => 'regular',
		),
	'Ranchers' =>
		array (
			0 => 'regular',
		),
	'Rancho' =>
		array (
			0 => 'regular',
		),
	'Rationale' =>
		array (
			0 => 'regular',
		),
	'Redressed' =>
		array (
			0 => 'regular',
		),
	'Reenie Beanie' =>
		array (
			0 => 'regular',
		),
	'Revalia' =>
		array (
			0 => 'regular',
		),
	'Ribeye' =>
		array (
			0 => 'regular',
		),
	'Ribeye Marrow' =>
		array (
			0 => 'regular',
		),
	'Righteous' =>
		array (
			0 => 'regular',
		),
	'Risque' =>
		array (
			0 => 'regular',
		),
	'Roboto' =>
		array (
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '700',
			5 => '900',
		),
	'Roboto Condensed' =>
		array (
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
	'Roboto Slab' =>
		array (
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '700',
		),
	'Rochester' =>
		array (
			0 => 'regular',
		),
	'Rock Salt' =>
		array (
			0 => 'regular',
		),
	'Rokkitt' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Romanesco' =>
		array (
			0 => 'regular',
		),
	'Ropa Sans' =>
		array (
			0 => 'regular',
		),
	'Rosario' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Rosarivo' =>
		array (
			0 => 'regular',
		),
	'Rouge Script' =>
		array (
			0 => 'regular',
		),
	'Ruda' =>
		array (
			0 => 'regular',
			1 => '700',
			2 => '900',
		),
	'Rufina' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Ruge Boogie' =>
		array (
			0 => 'regular',
		),
	'Ruluko' =>
		array (
			0 => 'regular',
		),
	'Rum Raisin' =>
		array (
			0 => 'regular',
		),
	'Ruslan Display' =>
		array (
			0 => 'regular',
		),
	'Russo One' =>
		array (
			0 => 'regular',
		),
	'Ruthie' =>
		array (
			0 => 'regular',
		),
	'Rye' =>
		array (
			0 => 'regular',
		),
	'Sacramento' =>
		array (
			0 => 'regular',
		),
	'Sail' =>
		array (
			0 => 'regular',
		),
	'Salsa' =>
		array (
			0 => 'regular',
		),
	'Sanchez' =>
		array (
			0 => 'regular',
		),
	'Sancreek' =>
		array (
			0 => 'regular',
		),
	'Sansita One' =>
		array (
			0 => 'regular',
		),
	'Sarina' =>
		array (
			0 => 'regular',
		),
	'Satisfy' =>
		array (
			0 => 'regular',
		),
	'Scada' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Schoolbell' =>
		array (
			0 => 'regular',
		),
	'Seaweed Script' =>
		array (
			0 => 'regular',
		),
	'Sevillana' =>
		array (
			0 => 'regular',
		),
	'Seymour One' =>
		array (
			0 => 'regular',
		),
	'Shadows Into Light' =>
		array (
			0 => 'regular',
		),
	'Shadows Into Light Two' =>
		array (
			0 => 'regular',
		),
	'Shanti' =>
		array (
			0 => 'regular',
		),
	'Share' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Share Tech' =>
		array (
			0 => 'regular',
		),
	'Share Tech Mono' =>
		array (
			0 => 'regular',
		),
	'Shojumaru' =>
		array (
			0 => 'regular',
		),
	'Short Stack' =>
		array (
			0 => 'regular',
		),
	'Siemreap' =>
		array (
			0 => 'regular',
		),
	'Sigmar One' =>
		array (
			0 => 'regular',
		),
	'Signika' =>
		array (
			0 => '300',
			1 => 'regular',
			2 => '600',
			3 => '700',
		),
	'Signika Negative' =>
		array (
			0 => '300',
			1 => 'regular',
			2 => '600',
			3 => '700',
		),
	'Simonetta' =>
		array (
			0 => 'regular',
			1 => '900',
		),
	'Sintony' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Sirin Stencil' =>
		array (
			0 => 'regular',
		),
	'Six Caps' =>
		array (
			0 => 'regular',
		),
	'Skranji' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Slackey' =>
		array (
			0 => 'regular',
		),
	'Smokum' =>
		array (
			0 => 'regular',
		),
	'Smythe' =>
		array (
			0 => 'regular',
		),
	'Sniglet' =>
		array (
			0 => 'regular',
			1 => '800',
		),
	'Snippet' =>
		array (
			0 => 'regular',
		),
	'Snowburst One' =>
		array (
			0 => 'regular',
		),
	'Sofadi One' =>
		array (
			0 => 'regular',
		),
	'Sofia' =>
		array (
			0 => 'regular',
		),
	'Sonsie One' =>
		array (
			0 => 'regular',
		),
	'Sorts Mill Goudy' =>
		array (
			0 => 'regular',
		),
	'Source Code Pro' =>
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '900',
		),
	'Source Sans Pro' =>
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '600',
			4 => '700',
			5 => '900',
		),
	'Special Elite' =>
		array (
			0 => 'regular',
		),
	'Spicy Rice' =>
		array (
			0 => 'regular',
		),
	'Spinnaker' =>
		array (
			0 => 'regular',
		),
	'Spirax' =>
		array (
			0 => 'regular',
		),
	'Squada One' =>
		array (
			0 => 'regular',
		),
	'Stalemate' =>
		array (
			0 => 'regular',
		),
	'Stalinist One' =>
		array (
			0 => 'regular',
		),
	'Stardos Stencil' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Stint Ultra Condensed' =>
		array (
			0 => 'regular',
		),
	'Stint Ultra Expanded' =>
		array (
			0 => 'regular',
		),
	'Stoke' =>
		array (
			0 => '300',
			1 => 'regular',
		),
	'Strait' =>
		array (
			0 => 'regular',
		),
	'Sue Ellen Francisco' =>
		array (
			0 => 'regular',
		),
	'Sunshiney' =>
		array (
			0 => 'regular',
		),
	'Supermercado One' =>
		array (
			0 => 'regular',
		),
	'Suwannaphum' =>
		array (
			0 => 'regular',
		),
	'Swanky and Moo Moo' =>
		array (
			0 => 'regular',
		),
	'Syncopate' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Tangerine' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Taprom' =>
		array (
			0 => 'regular',
		),
	'Tauri' =>
		array (
			0 => 'regular',
		),
	'Telex' =>
		array (
			0 => 'regular',
		),
	'Tenor Sans' =>
		array (
			0 => 'regular',
		),
	'Text Me One' =>
		array (
			0 => 'regular',
		),
	'The Girl Next Door' =>
		array (
			0 => 'regular',
		),
	'Tienne' =>
		array (
			0 => 'regular',
			1 => '700',
			2 => '900',
		),
	'Tinos' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Titan One' =>
		array (
			0 => 'regular',
		),
	'Titillium Web' =>
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '600',
			4 => '700',
			5 => '900',
		),
	'Trade Winds' =>
		array (
			0 => 'regular',
		),
	'Trocchi' =>
		array (
			0 => 'regular',
		),
	'Trochut' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Trykker' =>
		array (
			0 => 'regular',
		),
	'Tulpen One' =>
		array (
			0 => 'regular',
		),
	'Ubuntu' =>
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '700',
		),
	'Ubuntu Condensed' =>
		array (
			0 => 'regular',
		),
	'Ubuntu Mono' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Ultra' =>
		array (
			0 => 'regular',
		),
	'Uncial Antiqua' =>
		array (
			0 => 'regular',
		),
	'Underdog' =>
		array (
			0 => 'regular',
		),
	'Unica One' =>
		array (
			0 => 'regular',
		),
	'UnifrakturCook' =>
		array (
			0 => '700',
		),
	'UnifrakturMaguntia' =>
		array (
			0 => 'regular',
		),
	'Unkempt' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Unlock' =>
		array (
			0 => 'regular',
		),
	'Unna' =>
		array (
			0 => 'regular',
		),
	'VT323' =>
		array (
			0 => 'regular',
		),
	'Vampiro One' =>
		array (
			0 => 'regular',
		),
	'Varela' =>
		array (
			0 => 'regular',
		),
	'Varela Round' =>
		array (
			0 => 'regular',
		),
	'Vast Shadow' =>
		array (
			0 => 'regular',
		),
	'Vibur' =>
		array (
			0 => 'regular',
		),
	'Vidaloka' =>
		array (
			0 => 'regular',
		),
	'Viga' =>
		array (
			0 => 'regular',
		),
	'Voces' =>
		array (
			0 => 'regular',
		),
	'Volkhov' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Vollkorn' =>
		array (
			0 => 'regular',
			1 => '700',
		),
	'Voltaire' =>
		array (
			0 => 'regular',
		),
	'Waiting for the Sunrise' =>
		array (
			0 => 'regular',
		),
	'Wallpoet' =>
		array (
			0 => 'regular',
		),
	'Walter Turncoat' =>
		array (
			0 => 'regular',
		),
	'Warnes' =>
		array (
			0 => 'regular',
		),
	'Wellfleet' =>
		array (
			0 => 'regular',
		),
	'Wendy One' =>
		array (
			0 => 'regular',
		),
	'Wire One' =>
		array (
			0 => 'regular',
		),
	'Yanone Kaffeesatz' =>
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '700',
		),
	'Yellowtail' =>
		array (
			0 => 'regular',
		),
	'Yeseva One' =>
		array (
			0 => 'regular',
		),
	'Yesteryear' =>
		array (
			0 => 'regular',
		),
	'Zeyada' =>
		array (
			0 => 'regular',
		),
);